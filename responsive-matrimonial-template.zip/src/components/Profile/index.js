// Correct way to re-export named exports
export { ProfileHeader } from './ProfileHeader';
export { ProfileAbout } from './ProfileAbout';
export { ProfileGallery } from './ProfileGallery';
export { ProfileInterests } from './ProfileInterests';