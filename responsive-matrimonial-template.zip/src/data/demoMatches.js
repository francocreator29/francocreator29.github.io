export const demoMatches = [
    // Original profile (1/10)
    {
      id: 1,
      name: "Alex Johnson",
      age: 28,
      photos: [
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1520561805070-83c413349512?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "Stanford University",
      work: "Senior Developer at TechCorp",
      languages: ["English", "Spanish"],
      relationshipStatus: "Single",
      profession: "Software Engineer",
      location: "San Francisco, CA",
      bio: "Tech enthusiast who loves hiking and photography. Looking for someone to share adventures with!",
      interests: ["Hiking", "Photography", "Technology"],
      religion: "Christian",
      compatibility: 92
    },
  
    // Profile 2/10
    {
      id: 2,
      name: "Priya Patel",
      age: 25,
      photos: [
        "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1519699047748-de8e457a634e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "All India Institute of Medical Sciences",
      work: "Resident Doctor at Mumbai General",
      languages: ["Hindi", "English", "Gujarati"],
      relationshipStatus: "Never Married",
      profession: "Doctor",
      location: "Mumbai, India",
      bio: "Passionate about medicine and classical dance. Looking for someone who values family and career equally.",
      interests: ["Bharatanatyam", "Travel", "Reading"],
      religion: "Hindu",
      compatibility: 88
    },
  
    // Profile 3/10
    {
      id: 3,
      name: "Michael Chen",
      age: 31,
      photos: [
        "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1542178243-bc20204b769f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1526510747491-58f928ec870f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "Harvard Graduate School of Design",
      work: "Principal Architect at Studio Chen",
      languages: ["English", "Mandarin"],
      relationshipStatus: "Divorced",
      profession: "Architect",
      location: "New York, NY",
      bio: "Creative soul who loves designing sustainable buildings. Weekend painter and tea ceremony enthusiast.",
      interests: ["Sketching", "Minimalism", "Tea Culture"],
      religion: "Buddhist",
      compatibility: 85
    },
  
    // Profile 4/10
    {
      id: 4,
      name: "Aisha Khan",
      age: 26,
      photos: [
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "American University of Dubai",
      work: "Investigative Journalist at Gulf News",
      languages: ["Arabic", "English", "Urdu"],
      relationshipStatus: "Single",
      profession: "Journalist",
      location: "Dubai, UAE",
      bio: "Storyteller at heart. Love exploring new cultures through food and conversation. Passionate about human rights.",
      interests: ["Documentaries", "Scuba Diving", "Calligraphy"],
      religion: "Muslim",
      compatibility: 90
    },
  
    // Profile 5/10
    {
      id: 5,
      name: "David Wilson",
      age: 30,
      photos: [
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "Le Cordon Bleu Paris",
      work: "Head Chef at Étoile",
      languages: ["French", "English"],
      relationshipStatus: "Single",
      profession: "Chef",
      location: "Paris, France",
      bio: "Michelin-starred chef who believes food is the universal language of love. Looking for someone to share culinary adventures.",
      interests: ["Farm-to-Table", "Wine Tasting", "Cycling"],
      religion: "Atheist",
      compatibility: 82
    },
  
    // Profile 6/10
    {
      id: 6,
      name: "Sophia Rodriguez",
      age: 27,
      photos: [
        "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1548142813-c348350df52b?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "University of Barcelona",
      work: "Marine Biologist at Ocean Conservancy",
      languages: ["Spanish", "English", "Catalan"],
      relationshipStatus: "Single",
      profession: "Environmental Scientist",
      location: "Barcelona, Spain",
      bio: "Marine conservationist who splits time between the lab and the Mediterranean. Looking for a partner who cares about our planet.",
      interests: ["Scuba Diving", "Yoga", "Photography"],
      religion: "Catholic",
      compatibility: 95
    },
  
    // Profile 7/10
    {
      id: 7,
      name: "Kenji Tanaka",
      age: 29,
      photos: [
        "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1542178243-bc20204b769f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "University of Tokyo",
      work: "Robotics Engineer at Toyota",
      languages: ["Japanese", "English"],
      relationshipStatus: "Never Married",
      profession: "Robotics Engineer",
      location: "Tokyo, Japan",
      bio: "Building the future one robot at a time. Traditional tea ceremony practitioner and anime enthusiast.",
      interests: ["AI Research", "Go Strategy Game", "Anime"],
      religion: "Shinto",
      compatibility: 87
    },
  
    // Profile 8/10
    {
      id: 8,
      name: "Olivia Brown",
      age: 24,
      photos: [
        "https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1548142813-c348350df52b?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "Royal College of Art",
      work: "Creative Director at DesignStudio",
      languages: ["English", "French"],
      relationshipStatus: "Single",
      profession: "Graphic Designer",
      location: "London, UK",
      bio: "Visual storyteller and typography nerd. Love museum hopping and finding hidden gem cafes around the city.",
      interests: ["Typography", "Pottery", "Jazz Music"],
      religion: "Agnostic",
      compatibility: 89
    },
  
    // Profile 9/10
    {
      id: 9,
      name: "Marcus Wright",
      age: 32,
      photos: [
        "https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1526510747491-58f928ec870f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "University of Cape Town",
      work: "Wildlife Photographer (Freelance)",
      languages: ["English", "Afrikaans"],
      relationshipStatus: "Divorced",
      profession: "Photographer",
      location: "Cape Town, South Africa",
      bio: "Documenting Africa's wildlife before it disappears. Spend 8 months a year in the bush. Looking for someone who understands this lifestyle.",
      interests: ["Conservation", "Safaris", "Astrophotography"],
      religion: "Christian",
      compatibility: 84
    },
  
    // Profile 10/10
    {
      id: 10,
      name: "Elena Petrova",
      age: 27,
      photos: [
        "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
      ],
      education: "Moscow State University",
      work: "Data Scientist at Yandex",
      languages: ["Russian", "English", "French"],
      relationshipStatus: "Single",
      profession: "Data Scientist",
      location: "Moscow, Russia",
      bio: "Math geek who turned data into art. Competitive ballroom dancer on weekends. Looking for someone who appreciates both algorithms and elegance.",
      interests: ["Machine Learning", "Ballroom Dance", "Chess"],
      religion: "Orthodox Christian",
      compatibility: 91
    }
  ];